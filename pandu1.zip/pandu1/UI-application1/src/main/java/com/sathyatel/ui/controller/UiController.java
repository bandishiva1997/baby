package com.sathyatel.ui.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.sathyatel.ui.model.CallDetailsDTO;
import com.sathyatel.ui.model.ChangePlan;
import com.sathyatel.ui.model.CustomerDTO;
import com.sathyatel.ui.model.Friend;
import com.sathyatel.ui.model.Login;
import com.sathyatel.ui.model.PlanDTO;
import com.sathyatel.ui.model.RegisterBean;

@Controller
public class UiController {
	
	
	
	//Request URL for allPlans
		private static String ALLPLANS_URL="Http://3.134.81.45:4444/PlanApi/allPlans";
			
		//Request URL for register
		private static String REGISTER_URL="http://18.225.37.49:5588/Customer/register";
		
		//request URL-lOGIN
		private static String LOGIN_URL="http://18.225.37.49:5588/Customer/login";
		
		//Request URL for profile
		private static String CUSTOMERDETAILS_CUSTOMER_URL="http://18.225.37.49:5588/Customer/profile/{phoneNo}";
		
		
		//Request URL for addFriend
		private static String ADDFRIEND_URL="http://18.225.37.49:5577/FriendsDetails/addFriend";
			
		
		//Request URL for 
		private static String CALLDETAILS_URL="http://3.134.81.45:5556/CallDetailsApi/calledBy";
				
		//Request URL for 
	    private static String PLAN_URL="http://3.134.81.45:4444/PlanApi/planId";
    
    
				
	/*
	 * //Request URL for private static String
	 * CUSTOMER_CHANGEPLANID_URL="http://localhost:5588/Customer/profile/{phoneNo}";
	 * 
	 * private static String
	 * CUSTOMER_CHANGEPLANID_URL1="http://localhost:5588/Customer/change";
	 */
	
    
    
    
    @Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/index")
	public String getIndexpage() {
		return "index";
	}
	
	@GetMapping("/registerpage")
	public String getRegisterPage(Model model) {
		
		
		
		/*
		 * The given ParameterizedTypeReference is used to pass generic type
		 * information:
		 * 
		 * ParameterizedTypeReference is passed parameter in exchange()method,,when we want capture the collection of data in required(or)same type.. 
		 */
		//Call Microservice-PlanDetails
		
		
		ParameterizedTypeReference<List<PlanDTO>> typeRef=new ParameterizedTypeReference<List<PlanDTO>>(){};
		
		/* ResponseEntity object is a container which contains body for data,header and status*/
		ResponseEntity<List<PlanDTO>> re=restTemplate.exchange(ALLPLANS_URL,HttpMethod.GET,null,typeRef);
	   List<PlanDTO> planList=re.getBody();
	   RegisterBean registerBean=new RegisterBean();
	   registerBean.setPlansList(planList);
	   model.addAttribute("registerBean", registerBean);
	   return "register";
	 
	}
	
	@PostMapping("/addCustomer")
	public String addCustomer(@Valid @ModelAttribute RegisterBean registerBean,BindingResult result,Model model) {
		if(result.hasErrors()) {
			//Call Microservice-PlanDetails
			ParameterizedTypeReference<List<PlanDTO>> typeRef=new ParameterizedTypeReference<List<PlanDTO>>(){};
			ResponseEntity<List<PlanDTO>> re=restTemplate.exchange(ALLPLANS_URL,HttpMethod.GET,null,typeRef);
			
		   List<PlanDTO> planList=re.getBody();
		   System.out.println(planList);
		   
		   registerBean.setPlansList(planList);
		   model.addAttribute("registerBean", registerBean);
			return "register";
		}
		
		
		
		//call Microservice-customer
		
		String message=restTemplate.postForObject(REGISTER_URL,registerBean,String.class);
		model.addAttribute("message",message);
		return "success";
		}

	
	
	@GetMapping("/loginPage")
	public String getLoginPage() {
		return "login";
	}
	
	
	
	@PostMapping("/loginCustomer")
	public String loginCustomer(@RequestParam Long phoneNo,@RequestParam String password,Model model) {
		Login login=new Login();
		login.setPhoneNo(phoneNo);
		login.setPassword(password);
		
		CustomerDTO customerDto=restTemplate.getForObject(CUSTOMERDETAILS_CUSTOMER_URL,CustomerDTO.class,phoneNo);
		//call Microservice-customer
		boolean flag=restTemplate.postForObject(LOGIN_URL,login, Boolean.class);
		System.out.println("from customer:"+customerDto);
		
		if(flag==true) {
			model.addAttribute("planId",customerDto.getPlanId());
			model.addAttribute("phoneNo",phoneNo);
			return "home";
		}
		else {
			model.addAttribute("message","Bad Credentials");
			return "login";
		}
		}
	
		
	@GetMapping("/viewProfile")
	public String getProfile(@RequestParam Long phoneNo,Model model)
	{
		System.out.println(phoneNo);
		CustomerDTO customerDto=restTemplate.getForObject(CUSTOMERDETAILS_CUSTOMER_URL,CustomerDTO.class,phoneNo);
		System.out.println(customerDto);
		model.addAttribute("customerDto",customerDto);
		System.out.println(customerDto);
		return "profile";
	}
	
	
	
	
	@GetMapping("/addFriendsPage")
	public String getAddFriend() {
		return "addFriendPage";
	}
	
	 @PostMapping("/addFriends")
	    public String addFriends(@ModelAttribute Friend friend,Model model) {
		 System.out.println(friend);
	  
	    	System.out.println("from handler");
	    	String message=restTemplate.postForObject(ADDFRIEND_URL,friend, String.class);
	    	System.out.println("after resttemplate");
	    	model.addAttribute("message",message);
	    	System.out.println(message);
	    	return "addFriendPage";
	    }
   
	
	 
	 
	 @GetMapping("/allPlans")
    public String getAllPlans(Model model) {
    	ParameterizedTypeReference<List<PlanDTO>> typeRef=new ParameterizedTypeReference<List<PlanDTO>>(){};
    	ResponseEntity<List<PlanDTO>> response=restTemplate.exchange(ALLPLANS_URL, HttpMethod.GET,null,typeRef);
    	
    	List<PlanDTO> planList=response.getBody();
    	model.addAttribute("planDtoList",planList);
    	
    	System.out.println("planList");
    	return "allPlans";
    }
   
	
	 
	 
	 @GetMapping("/callDetails")
	public String callDetails(@RequestParam Long phoneNo,Model model) {
		
		  ParameterizedTypeReference<List<CallDetailsDTO>> typeRef=new ParameterizedTypeReference<List<CallDetailsDTO>>(){};
		  ResponseEntity<List<CallDetailsDTO>> response=restTemplate.exchange(CALLDETAILS_URL,HttpMethod.GET,null,typeRef,phoneNo);
		  List<CallDetailsDTO> callDtoList=response.getBody();
        
		model.addAttribute("callDtoList",callDtoList);
		System.out.println("callDtoList");
		return "callDetails";
	}

	
	 @GetMapping("/planById")
	public String getPlanById(@RequestParam String planId,Model model) {
	
		PlanDTO planDto=restTemplate.getForObject(PLAN_URL,PlanDTO.class,planId);
		model.addAttribute("planDto",planDto);
		return "specificPlan";
	}

	/*@GetMapping("/changePlanId")
	public String getChangePlanIdPage(@RequestParam Long phoneNo,Model model) {
		
		CustomerDTO customerDto=restTemplate.getForObject(CHANGEPLAN_URL,CustomerDTO.class,phoneNo);
		model.addAttribute("customerDto",customerDto);
	    return "changedPlanIdOfCustomer";	
	}*/
	
	/*@GetMapping("/changePlanPage")
	public String getChangePlanpage(@RequestParam Long phoneNo,Model model) {
		model.addAttribute("phoneNo",phoneNo);
		return "changePlanPage";
	}
 
	@PostMapping("/changedCustomerDetails")
	public String changedCustomerDetails(@RequestParam Long phoneNo,@RequestParam String planId,Model model) {
	
	ChangePlan  changePlan=new ChangePlan();
	changePlan.setPhoneNo(phoneNo);
	changePlan.setPlanId(planId);
	System.out.println("hiiiiiiii");
	CustomerDTO customerDto=restTemplate.postForObject(CUSTOMER_CHANGEPLANID_URL1,changePlan,CustomerDTO.class);
	System.out.println("hiiiiiiii after");
	model.addAttribute("planId",customerDto.getPlanId());
	model.addAttribute("customerDto",customerDto);
    return "changedCustomerDetails";	
    }*/
}






















